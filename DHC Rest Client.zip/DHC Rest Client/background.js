restoreLastSessionTabs();

//chrome.app.runtime.onLaunched.addListener(function() {
//
//  chrome.app.window.create('dhc.html', {
//    'bounds': {
//      'width': 1200,
//      'height': 800
//    }
//  });
//});

function guid() {
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
        .toString(16)
        .substring(1);
  }

  return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
      s4() + '-' + s4() + s4() + s4();
}

var base64Encode = function (data) {
  var b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
  var o1, o2, o3, h1, h2, h3, h4, bits, i = 0, ac = 0, enc = "", tmp_arr = [];

  if (!data) {
    return data;
  }

  data = utf8Encode(data);

  do { // pack three octets into four hexets
    o1 = data.charCodeAt(i++);
    o2 = data.charCodeAt(i++);
    o3 = data.charCodeAt(i++);

    bits = o1 << 16 | o2 << 8 | o3;

    h1 = bits >> 18 & 0x3f;
    h2 = bits >> 12 & 0x3f;
    h3 = bits >> 6 & 0x3f;
    h4 = bits & 0x3f;

    // use hexets to index into b64, and append result to encoded string
    tmp_arr[ac++] = b64.charAt(h1) + b64.charAt(h2) + b64.charAt(h3) + b64.charAt(h4);
  } while (i < data.length);

  enc = tmp_arr.join('');

  switch (data.length % 3) {
    case 1:
      enc = enc.slice(0, -2) + '==';
      break;
    case 2:
      enc = enc.slice(0, -1) + '=';
      break;
  }

  return enc;
};

var utf8Encode = function (string) {
  string = (string + '').replace(/\r\n/g, "\n").replace(/\r/g, "\n");

  var utftext = "",
      start,
      end;
  var stringl = 0,
      n;

  start = end = 0;
  stringl = string.length;

  for (n = 0; n < stringl; n++) {
    var c1 = string.charCodeAt(n);
    var enc = null;

    if (c1 < 128) {
      end++;
    } else if ((c1 > 127) && (c1 < 2048)) {
      enc = String.fromCharCode((c1 >> 6) | 192, (c1 & 63) | 128);
    } else {
      enc = String.fromCharCode((c1 >> 12) | 224, ((c1 >> 6) & 63) | 128, (c1 & 63) | 128);
    }
    if (enc !== null) {
      if (end > start) {
        utftext += string.substring(start, end);
      }
      utftext += enc;
      start = end = n + 1;
    }
  }

  if (end > start) {
    utftext += string.substring(start, string.length);
  }

  return utftext;
};

var payloadStore = {};

function retrieveDhcPayloadDefinition(key) {
  var data = payloadStore[key];
  if (data) {
    delete payloadStore[key];
  }
  return data;
}


chrome.runtime.onMessage.addListener(function (message, sender, response) {
  if (message.type === "mixpanel") {
    var json = JSON.stringify(message.payload);
    var base64Encoded = base64Encode(json);
    fetch("https://api.mixpanel.com/track/?data=" + base64Encoded + "&ip=1");
  }

  if (message.type === "mixpanel_engage") {
    var json = JSON.stringify(message.payload);
    var base64Encoded = base64Encode(json);
    fetch("https://api.mixpanel.com/engage/?data=" + base64Encoded + "&ip=1");
  }

  if (message.type === 'upgrade') {
    handleUpgrade();
  }

  if (message.type == "openRequest" && sender.tab != null) {
    var key = guid();
    var targetUrl = "dhc.html?key=" + key + "&payloadType=" + message.payloadType;
    if (message.targetTab) {
      var views = chrome.extension.getViews({type: "tab"});
      var targetTab = message.targetTab;
      for (var i = 0; i < views.length; i++) {
        var view = views[i];
        if (view.dhcTargetTab == targetTab) {
          view.dhcProcessPayload(message.payloadType, JSON.stringify(message.payload));
          chrome.tabs.update(view.dhcChromeTabId, {active: true});
          return;
        }
      }
      targetUrl += "&targetTab=" + targetTab
    }

    chrome.tabs.create({
      url: targetUrl,
      active: true
    }, function (tab) {
      var views = chrome.extension.getViews({type: "tab"});
      var windowObj = views.filter(function (windowObj) {
        return windowObj.location.search.indexOf("key=" + key) > -1;
      })[0];

      if (windowObj) {
        if (typeof windowObj.dhcProcessPayload === "function") {
          windowObj.dhcProcessPayload(message.payloadType, message.payload, sender.url);
        } else if (!windowObj.dhcPayloadDefinition) {
          windowObj.dhcPayloadDefinition = {
            payloadType: message.payloadType,
            payload: message.payload,
            url: sender.url
          }
        }
      } else {
        payloadStore[key] = {
          payloadType: message.payloadType,
          payload: message.payload,
          url: sender.url
        }
      }
    });
  }
})
;

chrome.runtime.onInstalled.addListener(function (details) {
  if (details.reason === 'install') {
    chrome.storage.local.set({
      'dhc.installed': 'true'
    });
  }
});

function handleUpgrade() {
  var openedTabsUrl = chrome.extension.getViews({type: 'tab'}).map(function (tab) {
    return tab.location.href;
  });

  chrome.storage.local.set({
    'dhc.opened.tabs': openedTabsUrl
  }, onSave);

  function onSave() {
    if (chrome.runtime.lastError) {
      // Just in case
      chrome.storage.local.remove('dhc.opened.tabs');
      return;
    }
    chrome.runtime.reload();
  }
}

function restoreLastSessionTabs() {
  chrome.storage.local.get('dhc.opened.tabs', function (openedTabs) {
    openedTabs = openedTabs['dhc.opened.tabs'];
    if (openedTabs) {
      openedTabs.forEach(function (url) {
        chrome.tabs.create({
          url: url
        }, clearOpenedTabs);
      });
    }

    function clearOpenedTabs() {
      chrome.storage.local.remove('dhc.opened.tabs');
    }
  });
}