CodeMirror.defineMode("http-headers", function () {
  //stub for http headers only syntax support
  return {
    token: function (stream, state) {

    },

    blankLine: function (state) {

    },

    startState: function () {

    }
  }
});
